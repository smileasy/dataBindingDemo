package com.example.myapplication;

import java.lang.reflect.Constructor;

public class MainModel {
    public String name;
    public String password;

    public MainModel(String name, String password) {
        this.name = name;
        this.password = password;
    }
}
